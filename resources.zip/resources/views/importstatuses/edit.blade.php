@php
    $html_tag_data = [];
    $title = 'Import Status Update';
    $description= ''
@endphp
@extends('layout',[
'html_tag_data'=>$html_tag_data,
'title'=>$title,
'description'=>$description
])

@section('css')
    <link rel="stylesheet" href="{{ asset('/css/vendor/select2.min.css') }}"/>
    <link rel="stylesheet" href="{{ asset('/css/vendor/select2-bootstrap4.min.css') }}"/>
    <link rel="stylesheet" href="{{ asset('/css/vendor/bootstrap-datepicker3.standalone.min.css') }}"/>
@endsection

@section('js_vendor')
    <script src="{{ asset('/js/vendor/imask.js') }}"></script>
    <script src="{{ asset('/js/vendor/select2.full.min.js') }}"></script>
    <script src="{{ asset('/js/vendor/datepicker/bootstrap-datepicker.min.js') }}"></script>
    <script src="{{ asset('/js/vendor/datepicker/locales/bootstrap-datepicker.es.min.js') }}"></script>
@endsection

@section('js_page')
    <script src="{{ asset('/js/pages/settings.general.js') }}"></script>
    <script src="{{ asset('/js/pages/discount.js') }}"></script>
@endsection


@section('content')
    <div class="container">
        <!-- Title and Top Buttons Start -->
        <div class="page-title-container">
            <div class="row">
                <!-- Title Start -->
                <div class="col-auto mb-3 mb-md-0 me-auto">
                    <div class="w-auto sw-md-30">
                        <a href="#" class="muted-link pb-1 d-inline-block breadcrumb-back">
                            <i data-cs-icon="chevron-left" data-cs-size="13"></i>
                            <span class="text-small align-middle">Home</span>
                        </a>
                        <h1 class="mb-0 pb-0 display-4" id="title">{{ $title }}</h1>
                    </div>
                </div>
                <!-- Title End -->
            </div>
        </div>

        <div class="row">
            <div class="col-12 mb-5">
                <section class="scroll-section" id="address">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    <form class="tooltip-end-top" id="addressForm" novalidate="novalidate" method="post" action="{{ route('update_importstatus') }}">
                        @csrf
                        <input type="hidden" name="id" class="form-control" value="{{ $importstatus->id }}">
                        <div class="card mb-5">
                            <div class="card-body">
                                <div class="row g-3">
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <div class="w-100" data-select2-id="1">
                                                <label class="form-label">Company List</label>
                                                <select class="select-single-no-search" name="company_id">
                                                    <option value="">Select Company</option>
                                                    @foreach($companies as $company)
                                                        <option value="{{ $company->id }}" {{ $company->id == $importstatus->company_id ? 'selected' : '' }}>{{ $company->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Performa</label>
                                            <input type="text" name="performa" autocomplete="off" class="form-control" value="{{ $importstatus->performa }}">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Date</label>
                                            <input type="text" name="date" autocomplete="off" class="form-control date-picker-close" value="{{ $importstatus->date }}">
                                        </div>
                                    </div>
                                </div>
                                <div class="row g-3">
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label class="form-label">Description</label>
                                            <textarea name="description" autocomplete="off" class="form-control">{{ $importstatus->description }}</textarea>
                                        </div>
                                    </div>

                                    <div class="appendable_div" id="appendable_div">
                                        @php $count = 0; @endphp
                                        @if(empty($importstatus_details))
                                            <div class="row g-3 repeatDiv" id="repeatDiv_0" style="margin-top:10px;">

                                                <input id="hidden_id" type="hidden" value="{{ $importstatus_detail->id != null ? $importstatus_detail->id : 0  }}" name="import_status_detail_id[]">
                                                <div class="col-md-2">
                                                    <div class="mb-3">
                                                        <div class="w-100">
                                                            <label class="form-label">Rate</label>
                                                            <input type="text" name="rate[]" autocomplete="off" class="form-control" id="rate_0">
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-2">
                                                    <div class="mb-3">
                                                        <div class="w-100">
                                                            <label class="form-label">Quantity</label>
                                                            <input type="text" name="quantity[]" autocomplete="off" class="form-control" id="quantity_0">
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-2">
                                                    <div class="mb-3">
                                                        <label class="form-label">Length</label>
                                                        <input type="text" name="length[]" autocomplete="off" class="form-control" id="length_0">
                                                    </div>
                                                </div>

                                                <div class="col-md-2">
                                                    <div class="mb-3">
                                                        <label class="form-label">Size</label>
                                                        <input type="text" name="size[]" autocomplete="off" class="form-control" id="size_0">
                                                    </div>
                                                </div>

                                                <div class="col-md-1">
                                                    <div class="mb-3">
                                                        <div class="w-100">
                                                            <a href="javascript:;" class="btn btn-sm btn-icon btn-icon-start btn-outline-primary ms-1 remove_raw_btn" data-id="{{ $importstatus_detail->id }}" data-raw="@php echo $count; @endphp">X</a>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        @endif
                                        @foreach($importstatus_details as $importstatus_detail)

                                        <div class="row g-3 repeatDiv" id="repeatDiv@php if($count != 0){ echo "_".$count; } @endphp" style="margin-top:10px;">

                                            <input id="hidden_edit_id" type="hidden" value="{{ $importstatus_detail->id != null ? $importstatus_detail->id : 0  }}" name="import_status_detail_id[]">
                                            <div class="col-md-2">
                                                <div class="mb-3">
                                                    <div class="w-100">
                                                        <label class="form-label">Rate</label>
                                                        <input type="text" name="rate[]" class="form-control rate_class" value="{{ $importstatus_detail->rate }}" id="rate_@php echo $count; @endphp">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="mb-3">
                                                    <div class="w-100">
                                                        <label class="form-label">Quantity</label>
                                                        <input type="text" name="quantity[]" class="form-control quantity_class" value="{{ $importstatus_detail->quantity }}" id="quantity_@php echo $count; @endphp">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="mb-3">
                                                    <label class="form-label">Length</label>
                                                    <input type="text" name="length[]" class="form-control length_class" value="{{ $importstatus_detail->length }}" id="length_@php echo $count; @endphp">
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="mb-3">
                                                    <label class="form-label">Size</label>
                                                    <input type="text" name="size[]" class="form-control size_class" value="{{ $importstatus_detail->size }}" id="size_@php echo $count; @endphp">
                                                </div>
                                            </div>

                                            <div class="col-md-1">
                                                <div class="mb-3">
                                                    <div class="w-100">
                                                        <a href="javascript:;" class="btn btn-sm btn-icon btn-icon-start btn-outline-primary ms-1 remove_raw_btn" data-id="{{ $importstatus_detail->id }}" data-raw="@php echo $count; @endphp">X</a>
                                                    </div>
                                                </div>
                                            </div>



                                        </div>
                                        @php $count++; @endphp
                                        @endforeach
                                        <div class="btn_div">
                                            <button type="button" class="btn btn-lg btn-icon btn-icon-start btn-outline-primary ms-1 mt-20" style="margin-top: 10px;" id="repeatDivBtn" data-increment="@php echo $count; @endphp">Add More Input</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer border-0 pt-0 d-flex justify-content-end align-items-center">
                                <div>
                                    <button class="btn btn-lg btn-icon btn-icon-start btn-outline-primary ms-1" type="submit">
                                        <span>Update</span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="acorn-icons acorn-icons-chevron-right undefined"><path d="M7 4L12.6464 9.64645C12.8417 9.84171 12.8417 10.1583 12.6464 10.3536L7 16"></path></svg>
                                    </button>
                                    <a class="btn btn-lg btn-icon btn-icon-start btn-outline-primary ms-1" href="{{ url('importstatuses') }}">
                                        <span>Back</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </form>
                </section>
{{--                <section class="scroll-section" id="basicSingle">--}}
{{--                    <h2 class="small-title">Basic Single</h2>--}}
{{--                    <div class="card mb-5">--}}
{{--                        <div class="card-body">--}}
{{--                            <div class="row" data-select2-id="20">--}}
{{--                                <div class="col-12 col-sm-6 col-xl-4" data-select2-id="19">--}}
{{--                                    <div class="w-100" data-select2-id="1">--}}
{{--                                        <label class="form-label">City</label>--}}
{{--                                        <select class="select-single-no-search">--}}
{{--                                            <option label="&nbsp;"></option>--}}
{{--                                            <option value="Tokyo" selected>Tokyo</option>--}}
{{--                                            <option value="...">...</option>--}}
{{--                                        </select>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </section>--}}
            </div>
        </div>

        <!-- Order List End -->


    </div>

    <script>
        var $newid;

        $("#repeatDivBtn").click(function () {

            $newid = $(this).data("increment");
            $repeatDiv = $("#repeatDiv").wrap('<div/>').parent().html();
            // alert($repeatDiv);
            $('#repeatDiv').unwrap();
            $($repeatDiv).insertAfter($(".repeatDiv").last());
            $(".repeatDiv").last().attr('id',   "repeatDiv" + '_' + $newid)
            $(".rate_class").last().attr('id',   "rate" + '_' + $newid)
            $(".quantity_class").last().attr('id',   "quantity" + '_' + $newid)
            $(".length_class").last().attr('id',   "length" + '_' + $newid)
            $(".size_class").last().attr('id',   "size" + '_' + $newid)
            $(".remove_raw_btn").last().attr('data-raw', $newid)
            $(".remove_raw_btn").last().attr('data-id', '')
            $("#repeatDiv" + '_' + $newid).find('input').val('');
            $("#repeatDiv" + '_' + $newid).append('<div class="input-group-append"><button type="button" class="btn btn-danger removeDivBtn" data-id="repeatDiv'+'_'+ $newid+'">Remove</button></div>');
            $newid++;
            $(this).data("increment", $newid);
        });

        $(document).on('click', '.removeDivBtn', function () {
            $divId = $(this).data("id");
            $("#"+$divId).remove();
            $inc = $("#repeatDivBtn").data("increment");
            $("#repeatDivBtn").data("increment", $inc-1);
        });

        $(document).on('click', '.remove_raw_btn', function () {
            $divId = $(this).data("raw");
            if($divId == 0) {
                $('#hidden_edit_id').val('');
                $('#rate_0').val('');
                $('#quantity_0').val('');
                $('#length_0').val('');
                $('#size_0').val('');
            } else {
                $("#repeatDiv_"+$divId).remove();
            }

            if($divId != '') {
                $id = $(this).data("id");
                $.ajax({
                    url: "{{ route('remove_single_importstatus') }}",
                    type: "POST",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {
                        id: $id
                    },
                    success: function (response) {
                        console.log(response);
                    },
                    error: function (xhr, status, error) {
                        console.error(error);
                    }
                });
            }
        });
    </script>
@endsection
