@php
    $html_tag_data = [];
    $title = 'Shipping Arrival Update';
    $description= ''
@endphp
@extends('layout',[
'html_tag_data'=>$html_tag_data,
'title'=>$title,
'description'=>$description
])

@section('css')
    <link rel="stylesheet" href="{{ asset('/css/vendor/select2.min.css') }}"/>
    <link rel="stylesheet" href="{{ asset('/css/vendor/select2-bootstrap4.min.css') }}"/>
    <link rel="stylesheet" href="{{ asset('/css/vendor/bootstrap-datepicker3.standalone.min.css') }}"/>
@endsection

@section('js_vendor')
    <script src="{{ asset('/js/vendor/imask.js') }}"></script>
    <script src="{{ asset('/js/vendor/select2.full.min.js') }}"></script>
    <script src="{{ asset('/js/vendor/datepicker/bootstrap-datepicker.min.js') }}"></script>
    <script src="{{ asset('/js/vendor/datepicker/locales/bootstrap-datepicker.es.min.js') }}"></script>
@endsection

@section('js_page')
    <script src="{{ asset('/js/pages/settings.general.js') }}"></script>
    <script src="{{ asset('/js/pages/discount.js') }}"></script>
@endsection


@section('content')
    <div class="container">
        <!-- Title and Top Buttons Start -->
        <div class="page-title-container">
            <div class="row">
                <!-- Title Start -->
                <div class="col-auto mb-3 mb-md-0 me-auto">
                    <div class="w-auto sw-md-30">
                        <a href="#" class="muted-link pb-1 d-inline-block breadcrumb-back">
                            <i data-cs-icon="chevron-left" data-cs-size="13"></i>
                            <span class="text-small align-middle">Home</span>
                        </a>
                        <h1 class="mb-0 pb-0 display-4" id="title">{{ $title }}</h1>
                    </div>
                </div>
                <!-- Title End -->

            </div>
        </div>
        <!-- Title and Top Buttons End -->

        <!-- Order List Start -->
        <div class="row">
            <div class="col-12 mb-5">
                <section class="scroll-section" id="address">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                        <form class="tooltip-end-top" id="addressForm" novalidate="novalidate" method="post" action="{{ route('update_shipping_arrival') }}">
                            @csrf
                            <input type="hidden" name="id" class="form-control" value="{{ $shipping_arrival->id }}">
                            <div class="card mb-5">
                                <div class="card-body">
                                    <div class="row g-3">
                                        <div class="col-md-4">
                                            <div class="mb-3">
                                                <div class="w-100" data-select2-id="1">
                                                    <label class="form-label">Company List</label>
                                                    <select class="select-single-no-search" name="company_id">
                                                        <option value="">Select Company</option>
                                                        @foreach($companies as $company)
                                                            <option value="{{ $company->id }}" {{ $company->id == $shipping_arrival->company_id ? 'selected' : '' }}>{{ $company->name }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="mb-3">
                                                <label class="form-label">BL Tracking Number</label>
                                                <input type="text" name="bl_tracking" autocomplete="off" class="form-control" value="{{ $shipping_arrival->bl_tracking }}">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="mb-3">
                                                <label class="form-label">No of Container</label>
                                                <input type="number" name="no_of_container" autocomplete="off" class="form-control" value="{{ $shipping_arrival->no_of_container }}">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row g-3">
                                        <div class="col-md-4">
                                            <div class="mb-3">
                                                <label class="form-label">Arrival Date</label>
                                                <input type="text" name="arrival_date" autocomplete="off" class="form-control date-picker-close" value="{{ $shipping_arrival->arrival_date }}">
                                            </div>
                                        </div>
                                        <div class="col-md-8">
                                            <div class="mb-3">
                                                <label class="form-label">Item Description</label>
                                                <textarea name="item_description" autocomplete="off" id="item_description" cols="30" rows="5" class="form-control">{{ $shipping_arrival->item_description }}</textarea>
                                            </div>
                                        </div>

                                        <div class="appendable_div" id="appendable_div">
                                            @php $count = 0; @endphp
                                            @if(empty($shipping_arrival_details))
                                                <div class="row g-3 repeatDiv" id="repeatDiv_0" style="margin-top:10px;">

                                                    <input id="hidden_id" type="hidden" value="{{ $shipping_arrival_detail->id != null ? $shipping_arrival_detail->id : 0  }}" name="shipping_arrival_detail_id[]">
                                                    <div class="col-md-2">
                                                        <div class="mb-3">
                                                            <div class="w-100">
                                                                <label class="form-label">Container Number</label>
                                                                <input type="text" name="container_number[]" autocomplete="off" class="form-control" id="container_number_0">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-1">
                                                        <div class="mb-3">
                                                            <div class="w-100">
                                                                <a href="javascript:;" class="btn btn-sm btn-icon btn-icon-start btn-outline-primary ms-1 remove_raw_btn" data-id="{{ $shipping_arrival_detail->id }}" data-raw="@php echo $count; @endphp">X</a>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            @endif
                                            @foreach($shipping_arrival_details as $shipping_arrival_detail)

                                                <div class="row g-3 repeatDiv" id="repeatDiv@php if($count != 0){ echo "_".$count; } @endphp" style="margin-top:10px;">

                                                    <input id="hidden_edit_id" type="hidden" value="{{ $shipping_arrival_detail->id != null ? $shipping_arrival_detail->id : 0  }}" name="shipping_arrival_detail_id[]">
                                                    <div class="col-md-2">
                                                        <div class="mb-3">
                                                            <div class="w-100">
                                                                <label class="form-label">Container Number</label>
                                                                <input type="text" name="container_number[]" class="form-control container_number_class" value="{{ $shipping_arrival_detail->container_number }}" id="container_number_@php echo $count; @endphp">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-1">
                                                        <div class="mb-3">
                                                            <div class="w-100">
                                                                <a href="javascript:;" class="btn btn-sm btn-icon btn-icon-start btn-outline-primary ms-1 remove_raw_btn" data-id="{{ $shipping_arrival_detail->id }}" data-raw="@php echo $count; @endphp">X</a>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                                @php $count++; @endphp
                                            @endforeach
                                            <div class="btn_div">
                                                <button type="button" class="btn btn-lg btn-icon btn-icon-start btn-outline-primary ms-1 mt-20" style="margin-top: 10px;" id="repeatDivBtn" data-increment="@php echo $count; @endphp">Add More Input</button>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                                <div class="card-footer border-0 pt-0 d-flex justify-content-end align-items-center">
                                    <div>
                                        <button class="btn btn-lg btn-icon btn-icon-start btn-outline-primary ms-1" type="submit">
                                            <span>Update</span>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="acorn-icons acorn-icons-chevron-right undefined"><path d="M7 4L12.6464 9.64645C12.8417 9.84171 12.8417 10.1583 12.6464 10.3536L7 16"></path></svg>
                                        </button>
                                        <a class="btn btn-lg btn-icon btn-icon-start btn-outline-primary ms-1" href="{{ url('shipping_arrivals') }}">
                                            <span>Back</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </form>
                </section>
            </div>
        </div>

        <!-- Order List End -->


    </div>

    <script>
        var $newid;

        $("#repeatDivBtn").click(function () {
            $newid = $(this).data("increment");
            $repeatDiv = $("#repeatDiv").wrap('<div/>').parent().html();
            $('#repeatDiv').unwrap();
            $($repeatDiv).insertAfter($(".repeatDiv").last());
            $(".repeatDiv").last().attr('id',   "repeatDiv" + '_' + $newid)
            $(".container_number_class").last().attr('id',   "container_number" + '_' + $newid)
            $(".remove_raw_btn").last().attr('data-raw', $newid)
            $(".remove_raw_btn").last().attr('data-id', '')
            $("#repeatDiv" + '_' + $newid).find('input').val('');
            $("#repeatDiv" + '_' + $newid).append('<div class="input-group-append"><button type="button" class="btn btn-danger removeDivBtn" data-id="repeatDiv'+'_'+ $newid+'">Remove</button></div>');
            $newid++;
            $(this).data("increment", $newid);
        });

        $(document).on('click', '.removeDivBtn', function () {
            $divId = $(this).data("id");
            $("#"+$divId).remove();
            $inc = $("#repeatDivBtn").data("increment");
            $("#repeatDivBtn").data("increment", $inc-1);
        });

        $(document).on('click', '.remove_raw_btn', function () {

            $divId = $(this).data("raw");
            if($divId == 0) {
                $('#hidden_edit_id').val('');
                $('#container_number_0').val('');
            } else {
                $("#repeatDiv_"+$divId).remove();
            }

            if($divId != '') {
                $id = $(this).data("id");
                $.ajax({
                    url: "{{ route('remove_single_shipping_arrival') }}",
                    type: "POST",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {
                        id: $id
                    },
                    success: function (response) {
                        console.log(response);
                    },
                    error: function (xhr, status, error) {
                        console.error(error);
                    }
                });
            }
        });
    </script>
@endsection
