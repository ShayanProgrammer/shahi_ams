@php
    $html_tag_data = [];
    $title = 'Add Shipping Arrival';
    $description= ''
@endphp
@extends('layout',[
'html_tag_data'=>$html_tag_data,
'title'=>$title,
'description'=>$description
])

@section('css')
    <link rel="stylesheet" href="{{ asset('/css/vendor/select2.min.css') }}"/>
    <link rel="stylesheet" href="{{ asset('/css/vendor/select2-bootstrap4.min.css') }}"/>
    <link rel="stylesheet" href="{{ asset('/css/vendor/bootstrap-datepicker3.standalone.min.css') }}"/>
@endsection

@section('js_vendor')
    <script src="{{ asset('/js/vendor/imask.js') }}"></script>
    <script src="{{ asset('/js/vendor/select2.full.min.js') }}"></script>
    <script src="{{ asset('/js/vendor/datepicker/bootstrap-datepicker.min.js') }}"></script>
    <script src="{{ asset('/js/vendor/datepicker/locales/bootstrap-datepicker.es.min.js') }}"></script>
@endsection

@section('js_page')
    <script src="{{ asset('/js/pages/settings.general.js') }}"></script>
    <script src="{{ asset('/js/pages/discount.js') }}"></script>
@endsection


@section('content')
    <div class="container">
        <!-- Title and Top Buttons Start -->
        <div class="page-title-container">
            <div class="row">
                <!-- Title Start -->
                <div class="col-auto mb-3 mb-md-0 me-auto">
                    <div class="w-auto sw-md-30">
                        <a href="#" class="muted-link pb-1 d-inline-block breadcrumb-back">
                            <i data-cs-icon="chevron-left" data-cs-size="13"></i>
                            <span class="text-small align-middle">Home</span>
                        </a>
                        <h1 class="mb-0 pb-0 display-4" id="title">{{ $title }}</h1>
                    </div>
                </div>
                <!-- Title End -->

                <!-- Top Buttons Start -->
            {{--                <div class="col-3 d-flex align-items-end justify-content-end">--}}
            {{--                    <!-- Check Button Start -->--}}
            {{--                    <div class="btn-group ms-1 check-all-container">--}}
            {{--                        <div class="btn btn-outline-primary btn-custom-control p-0 ps-3 pe-2" data-target="#checkboxTable">--}}
            {{--            <span class="form-check float-end">--}}
            {{--              <input type="checkbox" class="form-check-input" id="checkAll" />--}}
            {{--            </span>--}}
            {{--                        </div>--}}
            {{--                        <button--}}
            {{--                            type="button"--}}
            {{--                            class="btn btn-outline-primary dropdown-toggle dropdown-toggle-split"--}}
            {{--                            data-bs-offset="0,3"--}}
            {{--                            data-bs-toggle="dropdown"--}}
            {{--                            aria-haspopup="true"--}}
            {{--                            aria-expanded="false"--}}
            {{--                        ></button>--}}
            {{--                        <div class="dropdown-menu dropdown-menu-end">--}}
            {{--                            <a class="dropdown-item" href="#">--}}
            {{--                                <span class="align-middle d-inline-block">Status</span>--}}
            {{--                            </a>--}}
            {{--                            <a class="dropdown-item" href="#">--}}
            {{--                                <span class="align-middle d-inline-block">Move</span>--}}
            {{--                            </a>--}}
            {{--                            <a class="dropdown-item" href="#">--}}
            {{--                                <span class="align-middle d-inline-block">Delete</span>--}}
            {{--                            </a>--}}
            {{--                        </div>--}}
            {{--                    </div>--}}
            {{--                    <!-- Check Button End -->--}}
            {{--                </div>--}}
            <!-- Top Buttons End -->
            </div>
        </div>
        <!-- Title and Top Buttons End -->

    {{--        <!-- Controls Start -->--}}
    {{--        <div class="row mb-2">--}}
    {{--            <!-- Search Start -->--}}
    {{--            <div class="col-sm-12 col-md-5 col-lg-3 col-xxl-2 mb-1">--}}
    {{--                <div class="d-inline-block float-md-start me-1 mb-1 search-input-container w-100 shadow bg-foreground">--}}
    {{--                    <input class="form-control" placeholder="Search" />--}}
    {{--                    <span class="search-magnifier-icon">--}}
    {{--          <i data-cs-icon="search"></i>--}}
    {{--        </span>--}}
    {{--                    <span class="search-delete-icon d-none">--}}
    {{--          <i data-cs-icon="close"></i>--}}
    {{--        </span>--}}
    {{--                </div>--}}
    {{--            </div>--}}
    {{--            <!-- Search End -->--}}

    {{--            <div class="col-sm-12 col-md-7 col-lg-9 col-xxl-10 text-end mb-1">--}}
    {{--                <div class="d-inline-block">--}}
    {{--                    <!-- Print Button Start -->--}}
    {{--                    <button--}}
    {{--                        class="btn btn-icon btn-icon-only btn-foreground-alternate shadow"--}}
    {{--                        data-bs-toggle="tooltip"--}}
    {{--                        data-bs-placement="top"--}}
    {{--                        data-bs-delay="0"--}}
    {{--                        title="Print"--}}
    {{--                        type="button"--}}
    {{--                    >--}}
    {{--                        <i data-cs-icon="print"></i>--}}
    {{--                    </button>--}}
    {{--                    <!-- Print Button End -->--}}

    {{--                    <!-- Export Dropdown Start -->--}}
    {{--                    <div class="d-inline-block">--}}
    {{--                        <button class="btn p-0" data-bs-toggle="dropdown" type="button" data-bs-offset="0,3">--}}
    {{--            <span--}}
    {{--                class="btn btn-icon btn-icon-only btn-foreground-alternate shadow dropdown"--}}
    {{--                data-bs-delay="0"--}}
    {{--                data-bs-placement="top"--}}
    {{--                data-bs-toggle="tooltip"--}}
    {{--                title="Export"--}}
    {{--            >--}}
    {{--              <i data-cs-icon="download"></i>--}}
    {{--            </span>--}}
    {{--                        </button>--}}
    {{--                        <div class="dropdown-menu shadow dropdown-menu-end">--}}
    {{--                            <button class="dropdown-item export-copy" type="button">Copy</button>--}}
    {{--                            <button class="dropdown-item export-excel" type="button">Excel</button>--}}
    {{--                            <button class="dropdown-item export-cvs" type="button">Cvs</button>--}}
    {{--                        </div>--}}
    {{--                    </div>--}}
    {{--                    <!-- Export Dropdown End -->--}}

    {{--                    <!-- Length Start -->--}}
    {{--                    <div class="dropdown-as-select d-inline-block" data-childSelector="span">--}}
    {{--                        <button class="btn p-0 shadow" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-bs-offset="0,3">--}}
    {{--            <span--}}
    {{--                class="btn btn-foreground-alternate dropdown-toggle"--}}
    {{--                data-bs-toggle="tooltip"--}}
    {{--                data-bs-placement="top"--}}
    {{--                data-bs-delay="0"--}}
    {{--                title="Item Count"--}}
    {{--            >--}}
    {{--              10 Items--}}
    {{--            </span>--}}
    {{--                        </button>--}}
    {{--                        <div class="dropdown-menu shadow dropdown-menu-end">--}}
    {{--                            <a class="dropdown-item" href="#">5 Items</a>--}}
    {{--                            <a class="dropdown-item active" href="#">10 Items</a>--}}
    {{--                            <a class="dropdown-item" href="#">20 Items</a>--}}
    {{--                        </div>--}}
    {{--                    </div>--}}
    {{--                    <!-- Length End -->--}}
    {{--                </div>--}}
    {{--            </div>--}}
    {{--        </div>--}}
    <!-- Controls End -->

        <!-- Order List Start -->
        <div class="row">
            <div class="col-12 mb-5">
                <section class="scroll-section" id="address">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    <form class="tooltip-end-top" id="addressForm" novalidate="novalidate" method="post" action="{{ route('store_shipping_arrival') }}">
                        @csrf
                        <div class="card mb-5">
                            <div class="card-body">
                                <div class="row g-3">
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <div class="w-100" data-select2-id="1">
                                                <label class="form-label">Company List</label>
                                                <select class="select-single-no-search" name="company_id">
                                                    <option value="">Select Company</option>
                                                    @foreach($companies as $company)
                                                        <option value="{{ $company->id }}">{{ $company->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">BL Tracking Number</label>
                                            <input type="text" name="bl_tracking" autocomplete="off" class="form-control" value="{{ old('bl_tracking') }}">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">No of Container</label>
                                            <input type="number" name="no_of_container" autocomplete="off" class="form-control" value="{{ old('no_of_container') }}">
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Arrival Date</label>
                                            <input type="text" name="arrival_date" autocomplete="off" class="form-control date-picker-close" value="{{ old('arrival_date') }}">
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="mb-3">
                                            <label class="form-label">Item Description</label>
                                            <textarea name="item_description" autocomplete="off" id="item_description" cols="30" rows="5" class="form-control"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="appendable_div" id="appendable_div">
                                    <div class="row g-3 repeatDiv" id="repeatDiv" style="margin-top:10px;">

                                        <div class="col-md-4">
                                            <div class="mb-3">
                                                <div class="w-100">
                                                    <label class="form-label">Container Number</label>
                                                    <input type="text" name="container_number[]" autocomplete="off" class="form-control container_number_class" value="{{ old('container_number') }}">
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="btn_div">
                                        <button type="button" class="btn btn-lg btn-icon btn-icon-start btn-outline-primary ms-1 mt-20" style="margin-top: 10px;" id="repeatDivBtn" data-increment="1">Add More Input</button>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer border-0 pt-0 d-flex justify-content-end align-items-center">
                                <div>
                                    <button class="btn btn-lg btn-icon btn-icon-start btn-outline-primary ms-1" type="submit">
                                        <span>Save</span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="acorn-icons acorn-icons-chevron-right undefined"><path d="M7 4L12.6464 9.64645C12.8417 9.84171 12.8417 10.1583 12.6464 10.3536L7 16"></path></svg>
                                    </button>
                                    <a class="btn btn-lg btn-icon btn-icon-start btn-outline-primary ms-1" href="{{ url('shipping_arrivals') }}">
                                        <span>Back</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </form>
                </section>
            </div>
        </div>

        <!-- Order List End -->


    </div>

    <script>
        var $newid;

        $("#repeatDivBtn").click(function () {
            $newid = $(this).data("increment");
            $repeatDiv = $("#repeatDiv").wrap('<div/>').parent().html();
            // alert($repeatDiv);
            $('#repeatDiv').unwrap();
            $($repeatDiv).insertAfter($(".repeatDiv").last());
            $(".repeatDiv").last().attr('id',   "repeatDiv" + '_' + $newid);
            $("#repeatDiv" + '_' + $newid).append('<div class="input-group-append"><button type="button" class="btn btn-danger removeDivBtn" data-id="repeatDiv'+'_'+ $newid+'">Remove</button></div>');
            $newid++;
            $(this).data("increment", $newid);
        });
        $(document).on('click', '.removeDivBtn', function () {

            $divId = $(this).data("id");
            $("#"+$divId).remove();
            $inc = $("#repeatDivBtn").data("increment");
            $("#repeatDivBtn").data("increment", $inc-1);

        });
    </script>
@endsection
