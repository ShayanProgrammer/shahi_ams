<div class="nav-content d-flex">
    <!-- Logo Start -->
    <div class="logo position-relative">
        <a href="{{ url('dashboard') }}">
            <!-- Logo can be added directly -->
            <!-- <img src="{{ asset('/img/logo/logo-white.svg') }}" alt="logo" /> -->

            <!-- Or added via css to provide different ones for different color themes -->
            <div class="">
                <h2 class="nav-heading">Dashbaord</h2>
                <a href="{{ route('logout') }}" class="logout_btn">
                    <img src="{{ asset('img/profile/logout.png') }}" alt="" style="width:45px">
                </a>
            </div>
        </a>
    </div>
    <!-- Logo End -->

    <!-- User Menu Start -->
    <div class="user-container d-flex">
        <a href="{{ url('dashboard') }}" class="d-flex user position-relative">
            <img class="profile" alt="profile" src="{{ asset('/img/profile/profile-9.png') }}" />
            <div class="name">{{ $user->name }}</div>
        </a>
    </div>
    <!-- User Menu End -->

    <!-- Icons Menu Start -->
{{--    <ul class="list-unstyled list-inline text-center menu-icons">--}}
{{--        <li class="list-inline-item">--}}
{{--            <a href="#" data-bs-toggle="modal" data-bs-target="#searchPagesModal">--}}
{{--                <i data-cs-icon="search" data-cs-size="18"></i>--}}
{{--            </a>--}}
{{--        </li>--}}
{{--        <li class="list-inline-item">--}}
{{--            <a href="#" id="pinButton" class="pin-button">--}}
{{--                <i data-cs-icon="lock-on" class="unpin" data-cs-size="18"></i>--}}
{{--                <i data-cs-icon="lock-off" class="pin" data-cs-size="18"></i>--}}
{{--            </a>--}}
{{--        </li>--}}
{{--        <li class="list-inline-item">--}}
{{--            <a href="#" id="colorButton">--}}
{{--                <i data-cs-icon="light-on" class="light" data-cs-size="18"></i>--}}
{{--                <i data-cs-icon="light-off" class="dark" data-cs-size="18"></i>--}}
{{--            </a>--}}
{{--        </li>--}}
{{--        <li class="list-inline-item">--}}
{{--            <a href="#" data-bs-toggle="dropdown" data-bs-target="#notifications" aria-haspopup="true" aria-expanded="false" class="notification-button">--}}
{{--                <div class="position-relative d-inline-flex">--}}
{{--                    <i data-cs-icon="bell" data-cs-size="18"></i>--}}
{{--                    <span class="position-absolute notification-dot rounded-xl"></span>--}}
{{--                </div>--}}
{{--            </a>--}}
{{--            <div class="dropdown-menu dropdown-menu-end wide notification-dropdown scroll-out" id="notifications">--}}
{{--                <div class="scroll">--}}
{{--                    <ul class="list-unstyled border-last-none">--}}
{{--                        <li class="mb-3 pb-3 border-bottom border-separator-light d-flex">--}}
{{--                            <img src="{{ asset('/img/profile/profile-1.jpg') }}" class="me-3 sw-4 sh-4 rounded-xl align-self-center" alt="..." />--}}
{{--                            <div class="align-self-center">--}}
{{--                                <a href="#">Joisse Kaycee just sent a new comment!</a>--}}
{{--                            </div>--}}
{{--                        </li>--}}
{{--                        <li class="mb-3 pb-3 border-bottom border-separator-light d-flex">--}}
{{--                            <img src="{{ asset('/img/profile/profile-2.jpg') }}" class="me-3 sw-4 sh-4 rounded-xl align-self-center" alt="..." />--}}
{{--                            <div class="align-self-center">--}}
{{--                                <a href="#">New order received! It is total $147,20.</a>--}}
{{--                            </div>--}}
{{--                        </li>--}}
{{--                        <li class="mb-3 pb-3 border-bottom border-separator-light d-flex">--}}
{{--                            <img src="{{ asset('/img/profile/profile-3.jpg') }}" class="me-3 sw-4 sh-4 rounded-xl align-self-center" alt="..." />--}}
{{--                            <div class="align-self-center">--}}
{{--                                <a href="#">3 items just added to wish list by a user!</a>--}}
{{--                            </div>--}}
{{--                        </li>--}}
{{--                        <li class="pb-3 pb-3 border-bottom border-separator-light d-flex">--}}
{{--                            <img src="{{ asset('/img/profile/profile-6.jpg') }}" class="me-3 sw-4 sh-4 rounded-xl align-self-center" alt="..." />--}}
{{--                            <div class="align-self-center">--}}
{{--                                <a href="#">Kirby Peters just sent a new message!</a>--}}
{{--                            </div>--}}
{{--                        </li>--}}
{{--                    </ul>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </li>--}}
{{--    </ul>--}}
    <!-- Icons Menu End -->
    <!-- Icons Menu End -->

    <!-- Menu Start -->
    <div class="menu-container flex-grow-1">
        <ul id="menu" class="menu">
            <li>
                <a href="{{ url('dashboard') }}">
                    <i data-cs-icon="shop" class="icon" data-cs-size="18"></i>
                    <span class="label">Dashboard</span>
                </a>
            </li>
            @if($user->role_id == 1 || $user->role_id == 2)
            <li>
                <a href="#company">
                    <i data-cs-icon="cupcake" class="icon" data-cs-size="18"></i>
                    <span class="label">Company Accounts</span>
                </a>
                <ul id="company">
                    <li>
                        <a href="{{ url('companies') }}">
                            <span class="label">Company List</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{ url('importstatuses') }}">
                            <span class="label">Import Status</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{ url('packinglists') }}">
                            <span class="label">Packing List</span>
                        </a>
                    </li>
                </ul>
            </li>
            @endif
            <li>
                <a href="{{ url('shipping_arrivals') }}">
                    <i data-cs-icon="cart" class="icon" data-cs-size="18"></i>
                    <span class="label">Shipping Arrival</span>
                </a>
            </li>
            @if($user->role_id == 1 || $user->role_id == 2)
            <li>
                <a href="{{ url('clearing_agents') }}">
                    <i data-cs-icon="cart" class="icon" data-cs-size="18"></i>
                    <span class="label">Clearing Agents</span>
                </a>
            </li>
            @endif
            <li>
                <a href="#stocks">
                    <i data-cs-icon="user" class="icon" data-cs-size="18"></i>
                    <span class="label">Stock Management</span>
                </a>
                <ul id="stocks">
                    <li>
                        <a href="{{ url('warehouses') }}">
                            <span class="label">Warehouse List</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{ url('stocklists') }}">
                            <span class="label">Stock List</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{ url('packetlists') }}">
                            <span class="label">Packet List</span>
                        </a>
                    </li>
                    @if($user->role_id == 1 || $user->role_id == 2)
                    <li>
                        <a href="{{ url('stock_report') }}">
                            <span class="label">Stock Report</span>
                        </a>
                    </li>
                    @endif
                </ul>
            </li>
            <li>
                <a href="#customers">
                    <i data-cs-icon="user" class="icon" data-cs-size="18"></i>
                    <span class="label">Customer Accounts</span>
                </a>
                <ul id="customers">
                    <li>
                        <a href="{{ url('customers') }}">
                            <span class="label">Customer</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{ url('customer_bills') }}">
                            <span class="label">Customer Bill</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{ url('customer_payments') }}">
                            <span class="label">Customer Payments</span>
                        </a>
                    </li>
                </ul>
            </li>
{{--            {{ dd($user->role_id) }}--}}
            @if($user->role_id == 1)
            <li>
                <a href="#banks">
                    <i data-cs-icon="cart" class="icon" data-cs-size="18"></i>
                    <span class="label">Bank Accounts</span>
                </a>
                <ul id="banks">
                    <li>
                        <a href="{{ url('banks') }}">
                            <span class="label">Bank List</span>
                        </a>
                    </li>
                    <li>
                        <a href="{{ url('importduties') }}">
                            <span class="label">Import Duties</span>
                        </a>
                    </li>
                </ul>
            </li>
            @endif
            <li>
                <a href="{{ url('expenses') }}">
                    <i data-cs-icon="cart" class="icon" data-cs-size="18"></i>
                    <span class="label">Expense</span>
                </a>
            </li>
            @if($user->role_id == 1)
            <li>
                <a href="{{ url('users') }}">
                    <i data-cs-icon="cart" class="icon" data-cs-size="18"></i>
                    <span class="label">User</span>
                </a>
            </li>
            @endif

        </ul>
    </div>
    <!-- Menu End -->

    <!-- Mobile Buttons Start -->
    <div class="mobile-buttons-container">
        <!-- Menu Button Start -->
        <a href="#" id="mobileMenuButton" class="menu-button">
            <i data-cs-icon="menu"></i>
        </a>
        <!-- Menu Button End -->
    </div>
    <!-- Mobile Buttons End -->
</div>
<div class="nav-shadow"></div>
