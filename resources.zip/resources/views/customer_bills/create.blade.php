@php
    $html_tag_data = [];
    $title = 'Add Customer Bill';
    $description= ''
@endphp
@extends('layout',[
'html_tag_data'=>$html_tag_data,
'title'=>$title,
'description'=>$description
])

@section('css')
    <link rel="stylesheet" href="{{ asset('/css/vendor/select2.min.css') }}"/>
    <link rel="stylesheet" href="{{ asset('/css/vendor/select2-bootstrap4.min.css') }}"/>
    <link rel="stylesheet" href="{{ asset('/css/vendor/bootstrap-datepicker3.standalone.min.css') }}"/>
@endsection

@section('js_vendor')
    <script src="{{ asset('/js/vendor/imask.js') }}"></script>
    <script src="{{ asset('/js/vendor/select2.full.min.js') }}"></script>
    <script src="{{ asset('/js/vendor/datepicker/bootstrap-datepicker.min.js') }}"></script>
    <script src="{{ asset('/js/vendor/datepicker/locales/bootstrap-datepicker.es.min.js') }}"></script>
@endsection

@section('js_page')
    <script src="{{ asset('/js/pages/settings.general.js') }}"></script>
    <script src="{{ asset('/js/pages/discount.js') }}"></script>
@endsection


@section('content')
    <div class="container">
        <!-- Title and Top Buttons Start -->
        <div class="page-title-container">
            <div class="row">
                <!-- Title Start -->
                <div class="col-auto mb-3 mb-md-0 me-auto">
                    <div class="w-auto sw-md-30">
                        <a href="#" class="muted-link pb-1 d-inline-block breadcrumb-back">
                            <i data-cs-icon="chevron-left" data-cs-size="13"></i>
                            <span class="text-small align-middle">Home</span>
                        </a>
                        <h1 class="mb-0 pb-0 display-4" id="title">{{ $title }}</h1>
                    </div>
                </div>
                <!-- Title End -->

                <!-- Top Buttons Start -->
            {{--                <div class="col-3 d-flex align-items-end justify-content-end">--}}
            {{--                    <!-- Check Button Start -->--}}
            {{--                    <div class="btn-group ms-1 check-all-container">--}}
            {{--                        <div class="btn btn-outline-primary btn-custom-control p-0 ps-3 pe-2" data-target="#checkboxTable">--}}
            {{--            <span class="form-check float-end">--}}
            {{--              <input type="checkbox" class="form-check-input" id="checkAll" />--}}
            {{--            </span>--}}
            {{--                        </div>--}}
            {{--                        <button--}}
            {{--                            type="button"--}}
            {{--                            class="btn btn-outline-primary dropdown-toggle dropdown-toggle-split"--}}
            {{--                            data-bs-offset="0,3"--}}
            {{--                            data-bs-toggle="dropdown"--}}
            {{--                            aria-haspopup="true"--}}
            {{--                            aria-expanded="false"--}}
            {{--                        ></button>--}}
            {{--                        <div class="dropdown-menu dropdown-menu-end">--}}
            {{--                            <a class="dropdown-item" href="#">--}}
            {{--                                <span class="align-middle d-inline-block">Status</span>--}}
            {{--                            </a>--}}
            {{--                            <a class="dropdown-item" href="#">--}}
            {{--                                <span class="align-middle d-inline-block">Move</span>--}}
            {{--                            </a>--}}
            {{--                            <a class="dropdown-item" href="#">--}}
            {{--                                <span class="align-middle d-inline-block">Delete</span>--}}
            {{--                            </a>--}}
            {{--                        </div>--}}
            {{--                    </div>--}}
            {{--                    <!-- Check Button End -->--}}
            {{--                </div>--}}
            <!-- Top Buttons End -->
            </div>
        </div>
        <!-- Title and Top Buttons End -->


        <!-- Order List Start -->
        <div class="row">
            <div class="col-12 mb-5">
                <section class="scroll-section" id="address">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    <form class="tooltip-end-top" id="addressForm" novalidate="novalidate" method="post" action="{{ route('store_customer_bill') }}">
                        @csrf
                        <div class="card mb-5">
                            <div class="card-body">
                                <div class="row g-3">

                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Bill Number</label>
                                            <input type="text" name="bill_no" autocomplete="off" class="form-control" value="{{ $formattedBillNumber??'' }}" readonly>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <div class="w-100" data-select2-id="1">
                                                <label class="form-label">Customer List</label>
                                                <select class="select-single-no-search" name="customer_id">
                                                    <option value="">Select Customer</option>
                                                    @foreach($customers as $customer)
                                                        <option value="{{ $customer->id }}">{{ $customer->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label class="form-label">Date</label>
                                            <input type="text" autocomplete="off" name="date" class="form-control date-picker-close" value="{{ old('date') }}">
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <div class="w-100" data-select2-id="1">
                                                <label class="form-label">Payment Type</label>
                                                <select class="select-single-no-search" name="payment_type_id" id="payment_type_id">
                                                    <option value="" disabled>Select Payment Type</option>
                                                    @foreach($payment_types as $payment_type)
                                                        <option value="{{ $payment_type->id }}">{{ $payment_type->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="col-md-4" style="display: none;" id="cheque_no_div">
                                        <div class="mb-3">
                                            <label class="form-label">Cheque Number</label>
                                            <input type="text" name="cheque_no" autocomplete="off" class="form-control" value="{{ old('cheque_no') }}">
                                        </div>
                                    </div>

                                </div>
                                 <div class="appendable_div" id="appendable_div">
                                    <div class="row g-3 repeatDiv" id="repeatDiv" style="margin-top:10px;">

                                        <div class="col-md-2">
                                            <div class="mb-3">
                                                <div class="w-100">
                                                    <label class="form-label">Warehouse List</label>
                                                    <select class="form-control warehouse_id" name="warehouse_id[]" id="warehouse_id">
                                                        <option value="">Select Warehouse</option>
                                                        @foreach($warehouses as $warehouse)
                                                            <option value="{{ $warehouse->id }}">{{ $warehouse->name }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <div class="mb-3">
                                                <div class="w-100">
                                                    <label class="form-label">Stock List</label>
                                                    <select class="form-control stocklist_id" name="stocklist_id[]" id="stocklist_id">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <div class="mb-3">
                                                <div class="w-100">
                                                    <label class="form-label">Packing List</label>
                                                    <select class="form-control packetlist_id" name="packetlist_id[]" id="packetlist_id">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <div class="mb-3">
                                                <div class="w-100">
                                                    <label class="form-label">Size</label>
                                                    <select class="form-control size_id" name="size_id[]" id="size_id">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <div class="mb-3">
                                                <label class="form-label">Rate</label>
                                                <input type="text" name="rate[]" autocomplete="off" class="form-control" value="{{ old('rate') }}">
                                            </div>
                                        </div>

                                        <div class="col-md-2">
                                            <div class="mb-3">
                                                <label class="form-label">Quantity</label>
                                                <input type="text" name="quantity[]" autocomplete="off" class="form-control" value="{{ old('quantity') }}">
                                            </div>
                                        </div>

                                    </div>
                                     <div class="btn_div">
{{--                                        <a href="javascript:;" class="btn btn-lg btn-icon btn-icon-start btn-outline-primary ms-1" id="addmore_btn">Add More</a>--}}
                                         <button type="button" class="btn btn-lg btn-icon btn-icon-start btn-outline-primary ms-1 mt-20" style="margin-top: 10px;" id="repeatDivBtn" data-increment="1">Add More Input</button>
                                     </div>
                                 </div>
                            </div>
                            <div class="card-footer border-0 pt-0 d-flex justify-content-end align-items-center">
                                <div>
                                    <button class="btn btn-lg btn-icon btn-icon-start btn-outline-primary ms-1" type="submit">
                                        <span>Save</span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="acorn-icons acorn-icons-chevron-right undefined"><path d="M7 4L12.6464 9.64645C12.8417 9.84171 12.8417 10.1583 12.6464 10.3536L7 16"></path></svg>
                                    </button>
                                    <a class="btn btn-lg btn-icon btn-icon-start btn-outline-primary ms-1" href="{{ url('customer_bills') }}">
                                        <span>Back</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </form>
                </section>
            </div>
        </div>

        <script>
            $(document).ready(function () {

                var $newid;

                $("#repeatDivBtn").click(function () {

                    $newid = $(this).data("increment");
                    $repeatDiv = $("#repeatDiv").wrap('<div/>').parent().html();
                    // alert($repeatDiv);
                    $('#repeatDiv').unwrap();
                    $($repeatDiv).insertAfter($(".repeatDiv").last());
                    $(".repeatDiv").last().attr('id',   "repeatDiv" + '_' + $newid);
                    $("#repeatDiv" + '_' + $newid).append('<div class="input-group-append"><button type="button" class="btn btn-danger removeDivBtn" data-id="repeatDiv'+'_'+ $newid+'">Remove</button></div>');
                    $newid++;
                    $(this).data("increment", $newid);
                });
                $(document).on('click', '.removeDivBtn', function () {

                    $divId = $(this).data("id");
                    $("#"+$divId).remove();
                    $inc = $("#repeatDivBtn").data("increment");
                    $("#repeatDivBtn").data("increment", $inc-1);

                });



                $(document).on('change','.warehouse_id',function(){
                    var row_id = $(this).parent().parent().parent().parent().attr('id');
                    var warehouse_id = $(this).val();
                    // alert('#'+row_id+' .col-md-2 .mb-3 .w-100 .stocklist_id');
                    $.ajax({
                        url: '{{ route('get_stocklist_by_warehouse') }}',
                        data: {
                            warehouse_id: warehouse_id,
                        },
                        method: 'POST',
                        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                        dataType: 'json',
                        success: function(result){
                            var html_stock = '';
                            html_stock += '<option value="" selected>Select Container Number</option>';
                            $.each(result.stocklist, function(k, v) {
                                html_stock += '<option value='+v.id+'>'+v.container_number+'</option>';
                            });
                            $('#'+row_id+' .col-md-2 .mb-3 .w-100 .stocklist_id').html(html_stock);
                        }
                    })
                })
                $(document).on('change','.stocklist_id',function(){
                    var row_id = $(this).parent().parent().parent().parent().attr('id');
                    var stocklist_id = $(this).val();
                    $.ajax({
                        url: '{{ route('get_packetlist_by_stocklist') }}',
                        data: {
                            stocklist_id: stocklist_id,
                        },
                        method: 'POST',
                        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                        dataType: 'json',
                        success: function(result){
                            var html_packet = '';
                            html_packet += '<option value="" selected>Select Packing Item</option>';
                            $.each(result.packetlist, function(k, v) {
                                html_packet += '<option value='+v.id+'>'+v.description+'</option>';
                            });
                            $('#'+row_id+' .col-md-2 .mb-3 .w-100 .packetlist_id').html(html_packet);
                        }
                    })
                })
                $(document).on('change','.packetlist_id',function(){
                    var row_id = $(this).parent().parent().parent().parent().attr('id');
                    var packetlist_id = $(this).val();
                    $.ajax({
                        url: '{{ route('get_size_by_packetlist') }}',
                        data: {
                            packetlist_id: packetlist_id,
                        },
                        method: 'POST',
                        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                        dataType: 'json',
                        success: function(result){
                            var html_size = '';
                            html_size += '<option value="" selected>Select Size</option>';
                            $.each(result.packetlist_details, function(k, v) {
                                html_size += '<option value='+v.id+'>'+v.size+'</option>';
                            });
                            $('#'+row_id+' .col-md-2 .mb-3 .w-100 .size_id').html(html_size);
                        }
                    })
                })

            });

            $(document).ready(function () {
                $('#cheque_no_div').hide();
                $('#payment_type_id').change(function () {
                    var selectedOption = $(this).val();
                    if (selectedOption === '2') {
                        $('#cheque_no_div').show();
                    } else {
                        $('#cheque_no_div').hide();
                    }
                });
            });
        </script>

    </div>
@endsection
