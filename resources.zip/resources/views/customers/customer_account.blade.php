@php
    $html_tag_data = [];
    $title = 'Customer Account';
    $description= ''
@endphp
@extends('layout',[
'html_tag_data'=>$html_tag_data,
'title'=>$title,
'description'=>$description
])

@section('css')
@endsection

@section('js_vendor')
@endsection

@section('js_page')
    <script src="{{ asset('/js/cs/checkall.js') }}"></script>
    <script src="{{ asset('/js/pages/orders.list.js') }}"></script>
@endsection

@section('content')
    <div class="container">
        <!-- Title and Top Buttons Start -->
        <div class="page-title-container">
            <div class="row">
                <!-- Title Start -->
                <div class="col-auto mb-3 mb-md-0 me-auto">
                    <div class="w-auto sw-md-30">
                        <a href="#" class="muted-link pb-1 d-inline-block breadcrumb-back">
                            <i data-cs-icon="chevron-left" data-cs-size="13"></i>
                            <span class="text-small align-middle">Home</span>
                        </a>
                        <h1 class="mb-0 pb-0 display-4" id="title">{{ $title }}</h1>
                    </div>
                </div>
                <!-- Title End -->

                <!-- Top Buttons Start -->
                <div class="col-3 d-flex align-items-end justify-content-end">
                    <!-- Check Button Start -->
{{--                    <div class="btn-group ms-1 check-all-container">--}}

{{--                        <a href="{{ route('create_customer') }}" class="btn btn-outline-primary btn-icon btn-icon-start ms-0 ms-sm-1 w-100 w-md-auto">--}}
{{--                            <span>Add Customer</span>--}}
{{--                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="acorn-icons acorn-icons-plus undefined"><path d="M10 17 10 3M3 10 17 10"></path></svg>--}}
{{--                        </a>--}}
{{--                    </div>--}}
                    <!-- Check Button End -->
                </div>
                <!-- Top Buttons End -->
            </div>
        </div>
        <!-- Title and Top Buttons End -->

        <!-- Order List Start -->
        <div class="row">
            <div class="col-12 mb-5">
                <section class="scroll-section" id="basic">
                    <div class="card mb-5">
                        <div class="card-body">
                            <table class="table table-bordered table-hover table-striped" id="ajax_table">
                            </table>
                        </div>
                    </div>
                </section>
            </div>
        </div>
        <script>
            $(document).ready(function () {
                fetchList();
            });
            function fetchList(){

                $.ajax({
                    url: '{{ route('customer_account_list') }}',
                    method: 'POST',
                    data: {
                        customer: '{{ Request::segment(3) }}'
                    },
                    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                    success: result => {

                        let data = JSON.parse(result);
                        console.log(data);
                        // return false;
                        var _data = data.customer_accounts;
                        var total_debit = 0;
                        var total_credit = 0;
                        var total_amount = 0;


                        if ($.fn.DataTable.isDataTable('#ajax_table')) $('#ajax_table').DataTable().destroy();
                        $('#ajax_table').empty();
                        var table = $('#ajax_table').DataTable({
                            // dom: 'Blfrtip',

                            data: _data,
                            aaSorting: [[ 0, "asc" ]],
                            columns: [
                                {data: 'created_at', title: 'Date'},
                                {data: 'bill_no', title: 'Bill Number'},
                                {data: 'bank_name', title: 'Bank Name'},
                                {
                                    title: 'Payment Type',
                                    render: function (data, type, full, meta) {
                                        var payment_type;
                                        if(full['payment_type'] == 1){
                                            payment_type = 'Bill';
                                        } else {
                                            payment_type = 'Received';
                                        }
                                        return payment_type;
                                    }
                                },
                                {data: 'debit', title: 'Debit'},
                                {data: 'credit', title: 'Credit'},
                                {
                                    title: 'Total',
                                    render: function (data, type, full, meta) {
                                        // var total_debit = 0;
                                        total_debit += full['debit'];
                                        total_credit += full['credit'];

                                        total_amount = total_debit - total_credit;

                                        if(total_amount < 0){
                                            total_amount = "(" + (-1 * total_amount) + ")";
                                        }
                                        return total_amount;
                                    }
                                }
                            ],
                            dom: 'Blrtip',
                            buttons: [
                                {
                                    extend: 'excel',
                                    exportOptions:{orthogonal: 'export'},
                                    text: 'Excel',
                                    title: 'Customer Account'
                                },
                                {
                                    extend: 'pdf',
                                    exportOptions:{orthogonal: 'export'},
                                    text: 'PDF',
                                    title: 'Customer Account'
                                }
                            ]

                        })



                    }
                })
            }
        </script>
        <!-- Order List End -->
    </div>
@endsection
