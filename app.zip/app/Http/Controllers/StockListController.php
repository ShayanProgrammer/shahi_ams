<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\StockList;
use App\Models\Warehouse;
use DB;
use Illuminate\Http\Request;

class StockListController extends Controller
{
    public function index()
    {
        $stocklists = StockList::latest()->paginate(10);
        return view('stocklists.index', compact('stocklists'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    public function warehouse_stocklists()
    {
        $stocklists = StockList::latest()->paginate(10);
        return view('stocklists.index', compact('stocklists'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    public function stocklist_list(Request $request)
    {
        try {
            $query = DB::table('stock_lists')
                ->leftjoin('companies', 'companies.id', '=', 'stock_lists.company_id')
                ->leftjoin('warehouses', 'warehouses.id', '=', 'stock_lists.warehouse_id')
                ->select('stock_lists.*', 'companies.name as company_name', 'warehouses.name as warehouse_name');
            if (isset($request->company) && !empty($request->company)) {
                $query->where('stock_lists.company_id', '=', $request->company);
            }
            $stocklists = $query->where('stock_lists.is_deleted', 0)->get();

            echo json_encode([
                'stocklists' => $stocklists
            ]);
            exit;
        } catch (\Exception $ex) {
            return json_encode([]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $companies = Company::where('is_deleted', 0)->get();
        $warehouses = Warehouse::where('is_deleted', 0)->get();
        return view('stocklists.create', compact('companies','warehouses'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->all());
        $this->validate($request, [
            'company_id' => 'required',
            'warehouse_id' => 'required',
            'container_number' => 'required',
            'no_of_packets' => 'required',
            'date' => 'required'
        ], [
            'company_id.required' => 'Select company from company list option',
            'warehouse_id.required' => 'Select warehouse from warehouse list option',
            'container_number.required' => 'Container number is required',
            'no_of_packets.required' => 'Number of packets is required',
            'date.required' => 'Date is required',
        ]);

        $save_array = [
            'company_id'=> $request->get('company_id'),
            'warehouse_id'=> $request->get('warehouse_id'),
            'container_number'=> $request->get('container_number'),
            'no_of_packets'=> $request->get('no_of_packets'),
            'date'=> $request->get('date'),
        ];
        $stock_list = new StockList($save_array);
        $stock_list->save();

        return redirect()->route('stocklists')
            ->with('success', 'StockList created successfully.');
    }

    public function edit($id)
    {
        $stocklist = StockList::where('id', $id)->first();
        $companies = Company::where('is_deleted', 0)->get();
        $warehouses = Warehouse::where('is_deleted', 0)->get();
        return view('stocklists.edit', compact('stocklist', 'companies','warehouses'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {

        $this->validate($request, [
            'company_id' => 'required',
            'warehouse_id' => 'required',
            'container_number' => 'required',
            'no_of_packets' => 'required',
            'date' => 'required'
        ], [
            'company_id.required' => 'Select company from company list option',
            'warehouse_id.required' => 'Select warehouse from warehouse list option',
            'container_number.required' => 'Container number is required',
            'no_of_packets.required' => 'Number of packets is required',
            'date.required' => 'Date is required',
        ]);

        StockList::where('id', $request->id)
            ->update([
                'company_id' => $request->company_id,
                'warehouse_id' => $request->warehouse_id,
                'container_number' => $request->container_number,
                'no_of_packets' => $request->no_of_packets,
                'date' => $request->date
            ]);

        return redirect()->route('stocklists')
            ->with('success', 'Stock List updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete(Request $request)
    {
        StockList::where('id', $request->id)
            ->update([
                'is_deleted' => 1
            ]);
            echo json_encode(['message' => 'Deleted successfully']);
    }
}
