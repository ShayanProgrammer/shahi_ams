<?php

namespace App\Http\Controllers;

use App\Models\Warehouse;
use DB;
use Illuminate\Http\Request;

class WarehouseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $warehouses = Warehouse::latest()->paginate(10);
        return view('warehouses.index',compact('warehouses'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    public function warehouse_list(Request $request){
        try{
            $query = DB::table('warehouses');

//            if(isset($request->start) && !empty($request->start)){
//                $query->whereDate('client_leads.created_at', '>=', $request->start);
//            }
//            if(isset($request->end) && !empty($request->end)){
//                $query->whereDate('client_leads.created_at', '<=', $request->end);
//            }
//            if(isset($request->city_id) && !empty($request->city_id)){
//                $query->where('client_leads.city_id', '=', $request->city_id);
//            }
//            if(isset($request->class_id) && !empty($request->class_id)){
//                $array_class    = explode("-",$request->class_id,3);
//                $query->where('client_leads.class_id', '=', $array_class[0]);
//                $query->where('client_leads.class_category_id', '=', $array_class[1]);
//            }
//            if(isset($request->type_id) && !empty($request->type_id)){
//                $query->where('users.type', '=', $request->type_id);
//            }

            $warehouses = $query->where('is_deleted',0)->get();

//            dd($warehouses);

            echo json_encode([
                'warehouses' => $warehouses
            ]);
            exit;
        }catch(\Exception $ex){
            return json_encode([]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('warehouses.create');
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
        ], [
            'name.required' => 'Warehouse name is required',
        ]);
        $warehouse = new Warehouse([
            'name' => $request->get('name')
        ]);

        $warehouse->save();

        return redirect()->route('warehouses')
            ->with('success','Warehouse created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Warehouse $warehouse)
    {
        return view('warehouses.show',compact('warehouse'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id){
        $warehouse = Warehouse::where('id',$id)->first();
        return view('warehouses.edit',compact('warehouse'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {

        $this->validate($request,[
            'name' => 'required'
        ], [
            'name.required' => 'Warehouse name is required',
        ]);

        Warehouse::where('id', $request->id)
            ->update([
                'name' => $request->name
            ]);

        return redirect()->route('warehouses')
            ->with('success','Warehouse updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete(Request $request)
    {
        Warehouse::where('id', $request->id)
            ->update([
                'is_deleted' => 1
            ]);
            echo json_encode(['message' => 'Deleted successfully']);
    }
}
