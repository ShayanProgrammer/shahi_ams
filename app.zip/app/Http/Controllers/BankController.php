<?php

namespace App\Http\Controllers;

use App\Models\Bank;
use Illuminate\Http\Request;
use DB;

class BankController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $banks = Bank::latest()->paginate(10);
        return view('banks.index',compact('banks'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    public function bank_list(Request $request){
        try{


            $query = DB::table('banks');

//            if(isset($request->start) && !empty($request->start)){
//                $query->whereDate('client_leads.created_at', '>=', $request->start);
//            }
//            if(isset($request->end) && !empty($request->end)){
//                $query->whereDate('client_leads.created_at', '<=', $request->end);
//            }
//            if(isset($request->city_id) && !empty($request->city_id)){
//                $query->where('client_leads.city_id', '=', $request->city_id);
//            }
//            if(isset($request->class_id) && !empty($request->class_id)){
//                $array_class    = explode("-",$request->class_id,3);
//                $query->where('client_leads.class_id', '=', $array_class[0]);
//                $query->where('client_leads.class_category_id', '=', $array_class[1]);
//            }
//            if(isset($request->type_id) && !empty($request->type_id)){
//                $query->where('users.type', '=', $request->type_id);
//            }

            $banks = $query->where('is_deleted',0)->get();

//            dd($banks);

            echo json_encode([
                'banks' => $banks
            ]);
            exit;
        }catch(\Exception $ex){
            return json_encode([]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('banks.create');
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
        ], [
            'name.required' => 'Bank name is required',
        ]);

        $bank = new Bank([
            'name' => $request->get('name')
        ]);

        $bank->save();

        return redirect()->route('banks')
            ->with('success','Bank created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Bank $bank)
    {
        return view('banks.show',compact('bank'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id){
        $bank = Bank::where('id',$id)->first();
        return view('banks.edit',compact('bank'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {

        $this->validate($request,[
            'name' => 'required'
        ], [
            'name.required' => 'Bank name is required',
        ]);

        Bank::where('id', $request->id)
            ->update([
                'name' => $request->name
            ]);

        return redirect()->route('banks')
            ->with('success','Bank updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete(Request $request)
    {
        Bank::where('id', $request->id)
            ->update([
                'is_deleted' => 1
            ]);

        echo json_encode(['message' => 'Deleted successfully']);
    }
}
