<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\Customer;
use App\Models\CustomerAccount;
use App\Models\CustomerBill;
use App\Models\CustomerBillDetail;
use App\Models\PacketList;
use App\Models\PacketListDetail;
use App\Models\PaymentType;
use App\Models\StockList;
use App\Models\Warehouse;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class CustomerBillController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $customer_bills = CustomerBill::latest()->paginate(10);
        return view('customer_bills.index',compact('customer_bills'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }


    public function invoice($id)
    {
        $customer_details = CustomerBill::join('customers','customers.id','=', 'customer_bills.customer_id')
            ->join('payment_types','payment_types.id','=', 'customer_bills.payment_type_id')
        ->where('customer_bills.id', $id)
        ->select('customers.name','customers.phone','customer_bills.id as bill_no','customer_bills.payment_type_id','customer_bills.cheque_no','customer_bills.total','payment_types.name as payment_type_name')
        ->first();

//        $customer_bill_details = CustomerBillDetail::join('packet_list_details','packet_list_details.id','=', 'customer_bill_details.packetlist_detail_id')
//            ->join('packet_lists','packet_lists.id','=', 'customer_bill_details.packetlist_id')
//            ->selectRaw('ROW_NUMBER() OVER (ORDER BY customer_bill_details.id) AS serial_number','packet_lists.description','packet_list_details.size','customer_bill_details.rate','customer_bill_details.quantity')
//            ->where('customer_bill_details.customer_bill_id', $id)
//            ->get();

        $customer_bill_details = CustomerBillDetail::join('packet_list_details', 'packet_list_details.id', '=', 'customer_bill_details.packetlist_detail_id')
            ->join('packet_lists', 'packet_lists.id', '=', 'customer_bill_details.packetlist_id')
            ->selectRaw('ROW_NUMBER() OVER (ORDER BY customer_bill_details.id) AS serial_number, packet_lists.description, packet_list_details.size, customer_bill_details.rate, customer_bill_details.quantity')
            ->where('customer_bill_details.customer_bill_id', $id)
            ->get();

        $mytime = Carbon::now();
        $today = $mytime->toFormattedDateString();


        return view('invoices.index',compact('customer_details','customer_bill_details','today'));
    }

    public function get_stocklist_by_warehouse(Request $request)
    {
        $stocklists = StockList::where('warehouse_id',$request->warehouse_id)->where('is_deleted', 0)->get();
        echo json_encode([
            'stocklist' => $stocklists,
        ]);
    }

    public function get_packetlist_by_stocklist(Request $request)
    {
        $packetlists = PacketList::where('stock_list_id',$request->stocklist_id)->where('is_deleted', 0)->get();
        echo json_encode([
            'packetlist' => $packetlists,
        ]);
    }

    public function get_size_by_packetlist(Request $request)
    {
        $packetlist_details = PacketListDetail::where('packet_list_id',$request->packetlist_id)->where('is_deleted', 0)->get();
        echo json_encode([
            'packetlist_details' => $packetlist_details,
        ]);
    }

    public function customer_bill_list(Request $request){
        try{
            $query = DB::table('customer_bills')
            ->join('customers','customers.id','=','customer_bills.customer_id')
            ->join('payment_types','payment_types.id','=','customer_bills.payment_type_id')
            ->join('status','status.id','=','customer_bills.status_id')
            ->select('customer_bills.*','customers.name as customer_name','payment_types.name as payment_type','status.status');



//            if(isset($request->start) && !empty($request->start)){
//                $query->whereDate('client_leads.created_at', '>=', $request->start);
//            }
//            if(isset($request->end) && !empty($request->end)){
//                $query->whereDate('client_leads.created_at', '<=', $request->end);
//            }
//            if(isset($request->city_id) && !empty($request->city_id)){
//                $query->where('client_leads.city_id', '=', $request->city_id);
//            }
//            if(isset($request->class_id) && !empty($request->class_id)){
//                $array_class    = explode("-",$request->class_id,3);
//                $query->where('client_leads.class_id', '=', $array_class[0]);
//                $query->where('client_leads.class_category_id', '=', $array_class[1]);
//            }
//            if(isset($request->type_id) && !empty($request->type_id)){
//                $query->where('users.type', '=', $request->type_id);
//            }

            $customer_bills = $query->where('customer_bills.is_deleted',0)->get();

            echo json_encode([
                'customer_bills' => $customer_bills
            ]);
            exit;
        }catch(\Exception $ex){
            return json_encode([]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $customers = Customer::where('is_deleted', 0)->get();
        $warehouses = Warehouse::where('is_deleted', 0)->get();
        $stocklists = StockList::where('is_deleted', 0)->get();
        $packetlists = PacketList::where('is_deleted', 0)->get();
        $payment_types = PaymentType::where('is_deleted', 0)->get();
        $latestBillId = CustomerBill::latest('id')->pluck('id')->first();
        $formattedBillNumber = 'BN-' . str_pad($latestBillId + 1, 2, '0', STR_PAD_LEFT);
        return view('customer_bills.create',compact('stocklists', 'packetlists','warehouses','customers','payment_types','formattedBillNumber'));
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'customer_id' => 'required',
            'date' => 'required',
            'payment_type_id' => 'required',
        ], [
            'customer_id.required' => 'Company Name is required',
            'date.required' => 'Company Name is required',
            'payment_type_id.required' => 'Company Name is required',
        ]);

        $customer_bill = new CustomerBill([
            'customer_id' => $request->get('customer_id'),
            'date' => $request->get('date'),
            'payment_type_id' => $request->get('payment_type_id'),
            'cheque_no' => $request->get('cheque_no'),
        ]);

        //Insert Bill
        $customer_bill->save();

        $product_arr = array();
        $total = 0;
        foreach ($request->warehouse_id as $key => $product) {
            $product_arr[] = [
                'total' => $request->rate[$key]*$request->quantity[$key]
            ];
        }

        $arr = array();
        foreach ($request->warehouse_id as $key => $value) {
            $arr[] = [
                'warehouse_id' => $value,
                'customer_bill_id' => $customer_bill->id,
                'stocklist_id' => $request->stocklist_id[$key],
                'packetlist_id' => $request->packetlist_id[$key],
                'packetlist_detail_id' => $request->size_id[$key],
                'rate' => $request->rate[$key],
                'quantity' => $request->quantity[$key],
            ];
//            $test = array_sum($arr['total']);
        }

        foreach($product_arr as $a) {
            $total += (int)$a['total'];
        }

        //Insert Bill Details
        CustomerBillDetail::insert($arr);

        //Calculate Total Amount
        CustomerBill::where('id',$customer_bill->id)->update(['total'=>$total]);

        $customer_account = new CustomerAccount([
            'customer_id' => $request->get('customer_id'),
            'customer_bill_id' => $customer_bill->id,
            'debit' => $total
        ]);

        $customer_account->save();

        return redirect()->route('customer_bills')
            ->with('success','Customer Bill created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(CustomerBill $customer_bill)
    {
        return view('customer_bills.show',compact('customer_bill'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id){
        $customer_bill = CustomerBill::where('id',$id)->first();

        $customers = Customer::where('is_deleted', 0)->get();
        $warehouses = Warehouse::where('is_deleted', 0)->get();
        $stocklists = StockList::where('is_deleted', 0)->get();
        $packetlists = PacketList::where('is_deleted', 0)->get();
        $packetlistdetails = PacketListDetail::where('is_deleted', 0)->get();
        $payment_types = PaymentType::where('is_deleted', 0)->get();
        $customer_bill_details = CustomerBillDetail::where('customer_bill_id', $customer_bill->id)->where('is_deleted', 0)->get();
        return view('customer_bills.edit',compact('packetlistdetails','customer_bill','customer_bill_details','customers','warehouses','stocklists','packetlists','payment_types'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $this->validate($request,[
            'customer_id' => 'required',
            'warehouse_id' => 'required',
            'stocklist_id' => 'required',
            'packetlist_id' => 'required',
            'date' => 'required',
            'bill_no' => 'required',
            'rate' => 'required',
            'quantity' => 'required'
        ]);

        CustomerBill::where('id', $request->id)
            ->update([
                'customer_id' => $request->customer_id,
                'warehouse_id' => $request->warehouse_id,
                'stocklist_id' => $request->stocklist_id,
                'packetlist_id' => $request->packetlist_id,
                'date' => $request->date,
                'payment_type' => 1,
                'bill_no' => $request->bill_no,
                'rate' => $request->rate,
                'quantity' => $request->quantity,
                'debit' => $request->debit,
                'credit' => $request->credit
            ]);

        return redirect()->route('customer_bills')
            ->with('success','Customer Bill updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete(Request $request)
    {
        CustomerBill::where('id', $request->id)
            ->update([
                'is_deleted' => 1
            ]);
            echo json_encode(['message' => 'Deleted successfully']);
    }

    public function customer_bill_detail(Request $request){
        $customerBillDetail = CustomerBillDetail::join('warehouses','warehouses.id','=','customer_bill_details.warehouse_id')
            ->join('stock_lists','stock_lists.id','=','customer_bill_details.stocklist_id')
            ->join('packet_lists','packet_lists.id','=','customer_bill_details.packetlist_id')
            ->join('packet_list_details','packet_list_details.id','=','customer_bill_details.packetlist_detail_id')
            ->where('customer_bill_details.customer_bill_id', $request->customer_bill_id)->where('customer_bill_details.is_deleted', 0)
            ->select('customer_bill_details.*','warehouses.name as warehouse_name','stock_lists.container_number as container_name','packet_lists.description as packet_name','packet_list_details.size as packet_list_size')
            ->get();
        echo json_encode(["customer_bill_detail" => $customerBillDetail]);
        exit();
    }

    public function remove_single_customer_bill(Request $request)
    {
        CustomerBillDetail::where('id', $request->id)
            ->update([
                'is_deleted' => 1
            ]);
        echo json_encode([
            'success' => true
        ]);
    }
}
